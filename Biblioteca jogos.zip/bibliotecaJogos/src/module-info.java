/**
 * 
 */
/**
 * 
 */
module bibliotecaJogos {
	requires java.desktop;
}