package bibliotecaJogos;

public interface gerenciarPosse {
		boolean Possui();
		void naoPossui();
}
