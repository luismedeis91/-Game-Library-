package bibliotecaJogos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MatrizJogos {
	protected List<Game> indiceGeral;
    protected HashMap<Integer, List<Game>> indicesPorGenero;
    
    public static final List<String> GENEROS_VALIDOS = List.of("rpg", "aventura", "luta", "simulação", "corrida", "carta");

    public MatrizJogos() {
        this.indiceGeral = new ArrayList<>();
        this.indicesPorGenero = new HashMap<>();
    }

    public void adicionarJogo(Game jogo) {
        
        indiceGeral.add(jogo);
        System.out.println("Jogo '" + jogo.getNome() + "' adicionado ao índice geral na posição " + (indiceGeral.size() - 1));

        
        int linhaGenero = getLinhaGenero(jogo.getGenero());
        if (linhaGenero != -1) {
            indicesPorGenero.putIfAbsent(linhaGenero, new ArrayList<>());
            indicesPorGenero.get(linhaGenero).add(jogo);
            System.out.println("Jogo '" + jogo.getNome() + "' adicionado ao índice de gênero '" + jogo.getGenero() + "' na posição " + (indicesPorGenero.get(linhaGenero).size() - 1));
        } else {
            System.out.println("Gênero '" + jogo.getGenero() + "' não é reconhecido e não foi adicionado a um índice de gênero.");
        }
    }
    
    public int getIndiceGeral(Game jogo) {
        return indiceGeral.indexOf(jogo);
    }
    
    
    public void removerJogo(Game jogo) {
        indiceGeral.remove(jogo);
        int linhaGenero = getLinhaGenero(jogo.getGenero());
        if (linhaGenero != -1 && indicesPorGenero.containsKey(linhaGenero)) {
            indicesPorGenero.get(linhaGenero).remove(jogo);
            System.out.println("Jogo '" + jogo.getNome() + "' removido do índice de gênero '" + jogo.getGenero() + "'.");
        } else {
            System.out.println("Jogo '" + jogo.getNome() + "' não foi encontrado em um índice de gênero.");
        }
    }

    
    protected int getLinhaGenero(String genero) {
        switch (genero.toLowerCase()) {
            case "rpg":
                return 1;
            case "aventura":
                return 2;
            case "luta":
                return 3;
            case "simulação":
                return 4;
            case "corrida":
                return 5;
            case "carta":
                return 6;
                
            default:
                return -1;
        }
    }

    public void exibirMatriz() {
        System.out.println("Índice geral:");
        for (int i = 0; i < indiceGeral.size(); i++) {
            System.out.println("[" + i + "] " + indiceGeral.get(i).getNome());
        }

        System.out.println("\nÍndice por gênero:");
        for (int linha : indicesPorGenero.keySet()) {
            List<Game> jogosDoGenero = indicesPorGenero.get(linha);
            
            if (!jogosDoGenero.isEmpty()) {
                System.out.println("Gênero: " + getNomeGenero(linha));
                for (int i = 0; i < jogosDoGenero.size(); i++) {
                    System.out.println("[" + i + "] " + jogosDoGenero.get(i).getNome());
                }
            }
        }
    }

    protected String getNomeGenero(int linhaGenero) {
        switch (linhaGenero) {
            case 1:
                return "rpg";
            case 2:
                return "aventura";
            case 3:
            	return "luta";
            case 4:
            	return "simulação";
            case 5:
            	return "corrida";
            case 6:
            	return "carta";
            	
            default:
                return "Gênero desconhecido";
        }
    }
}
