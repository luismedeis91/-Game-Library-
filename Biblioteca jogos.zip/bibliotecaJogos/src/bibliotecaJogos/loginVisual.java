package bibliotecaJogos;

import javax.swing.*;
import java.awt.*;

public class loginVisual extends JFrame  {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField fieldNome;
    private JTextField fieldNomeJogo;
    private JTextField fieldEmpresa;
    private JTextField fieldAno;
    private JTextField fieldNota;
    private JTextField fieldGenero;
    private MatrizJogos matrizJogos;
    private buscaJogos busca;
    private Player player;
    

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                loginVisual frame = new loginVisual();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public loginVisual() {
    	
        matrizJogos = new MatrizJogos(); // Inicializa a matriz
        player = new Player();
        busca = new buscaJogos(matrizJogos); // Inicializa o objeto buscaJogos
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 332, 300);
        contentPane = new JPanel();
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel labelNome = new JLabel("Nome:");
        labelNome.setBounds(55, 54, 46, 14);
        contentPane.add(labelNome);

        fieldNome = new JTextField();
        fieldNome.setBounds(55, 79, 141, 20);
        contentPane.add(fieldNome);
        fieldNome.setColumns(10);

        JButton enviarBotao = new JButton("Login");
        enviarBotao.setBounds(55, 193, 99, 23);
        contentPane.add(enviarBotao);

        JLabel labelSenha = new JLabel("Senha:");
        labelSenha.setBounds(55, 116, 46, 14);
        contentPane.add(labelSenha);

        JTextField passwordField = new JPasswordField();
        passwordField.setBounds(55, 141, 139, 20);
        contentPane.add(passwordField);

        enviarBotao.addActionListener(e -> abrirPaginaInicial());
    }

    private void abrirPaginaInicial() {
        if (fieldNome.getText().trim().isEmpty()) {
            // Exibe a mensagem de erro
            JOptionPane.showMessageDialog(this, "Por favor, preencha todos os campos!");
            return;    }

        // Continuação da lógica caso o nome seja válido
        JOptionPane.showMessageDialog(this, "Login bem-sucedido!");
        JFrame novaPagina = new JFrame("Página Inicial");
        novaPagina.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        novaPagina.setBounds(100, 100, 500, 400);
        novaPagina.getContentPane().setLayout(null);

        JLabel label = new JLabel("Bem-vindo, " + fieldNome.getText());
        label.setBounds(50, 20, 300, 30);
        novaPagina.getContentPane().add(label);

        JButton botaoAdicionar = new JButton("Adicionar Jogo");
        botaoAdicionar.setBounds(50, 100, 150, 30);
        botaoAdicionar.addActionListener(e -> abrirTelaAdicionarJogo());
        novaPagina.getContentPane().add(botaoAdicionar);

        JButton botaoExibir = new JButton("Exibir Jogos");
        botaoExibir.setBounds(210, 100, 150, 30);
        //botaoExibir.addActionListener(e -> matrizJogos.exibirMatriz());
        botaoExibir.addActionListener(e -> matrizJogos.exibirMatriz());
        novaPagina.getContentPane().add(botaoExibir);

        JButton botaoRemover = new JButton("Remover Jogo");
        botaoRemover.setBounds(50, 150, 150, 30);
        botaoRemover.addActionListener(e -> removerJogo());
        novaPagina.getContentPane().add(botaoRemover);

        JButton botaoSalvarCatalogo = new JButton("Salvar Catálogo");
        botaoSalvarCatalogo.setBounds(210, 150, 150, 30);
        botaoSalvarCatalogo.addActionListener(e -> salvarCatalogoPorGenero());
        novaPagina.getContentPane().add(botaoSalvarCatalogo);

        JButton exibirGenero = new JButton("Gêneros");
        exibirGenero.setBounds(50, 200, 150, 30);
        exibirGenero.addActionListener(e -> JOptionPane.showMessageDialog(exibirGenero, 
            "Gêneros disponíveis: AVENTURA || CARTA || CORRIDA || LUTA || RPG || SIMULAÇÃO"));
        novaPagina.getContentPane().add(exibirGenero);
        
        JButton playerBotao = new JButton("Dados do " + fieldNome.getText());
        playerBotao.setBounds(210, 200, 150, 30);
        playerBotao.addActionListener(e -> player.dados());
        novaPagina.getContentPane().add(playerBotao);

        JButton botaoVoltar = new JButton("Voltar");
        botaoVoltar.setBounds(210, 300, 150, 30);
        botaoVoltar.addActionListener(e -> {
            novaPagina.dispose();  // Fecha a janela atual
            new loginVisual().setVisible(true);  // Cria uma nova instância da tela de login e a exibe
        });
        novaPagina.getContentPane().add(botaoVoltar);

        novaPagina.setVisible(true);
    }
    
    private void removerJogo() {
        String nomeJogo = JOptionPane.showInputDialog(this, "Digite o nome do jogo a ser removido:");
        
        // Verifica se o usuário clicou em "Cancelar" ou deixou o campo vazio
        if (nomeJogo == null || nomeJogo.trim().isEmpty()) {
            return; // Fecha a caixa de diálogo sem fazer nada
        }
        
        // Caso o usuário tenha digitado algo, tenta remover o jogo
        busca.removerGame(nomeJogo.trim());;
    }
   



    
    private void salvarCatalogoPorGenero() {
        // Pergunta ao usuário qual gênero deseja salvar
        String generoFiltro = JOptionPane.showInputDialog(null, "Digite o gênero para salvar o catálogo");

        // Verifica se o usuário forneceu um gênero válido
        if (generoFiltro != null && !generoFiltro.trim().isEmpty()) {
            generoFiltro = generoFiltro.trim().toLowerCase(); // Converte para minúsculas

            // Valida se o gênero informado é válido
            if (!generoFiltro.equalsIgnoreCase("rpg") && !generoFiltro.equalsIgnoreCase("aventura") && 
                !generoFiltro.equalsIgnoreCase("luta") && !generoFiltro.equalsIgnoreCase("simulação") && 
                !generoFiltro.equalsIgnoreCase("corrida") && !generoFiltro.equalsIgnoreCase("carta")) {
                // Se o gênero não for válido, lança uma exceção ou exibe uma mensagem
                System.out.println("Gênero inválido! Use um gênero válido.");
                return; // Impede o restante da execução
            }

            // Salva o catálogo filtrado por gênero
            String caminhoArquivoGenero = "catalogo_" + generoFiltro + ".csv";
            busca.salvarCatalogo(caminhoArquivoGenero, generoFiltro);
            //System.out.println("O catálogo filtrado por gênero (" + generoFiltro + ") foi salvo.");

            // Salva o catálogo geral
            String caminhoArquivoGeral = "catalogo_geral.csv";
            busca.salvarCatalogo(caminhoArquivoGeral, null);
            //System.out.println("Teste concluído. O catálogo foi salvo.");
        } else {
            System.out.println("Gênero não fornecido ou inválido. O catálogo não foi salvo.");
        }
    }

   
    private void abrirTelaAdicionarJogo() throws NumberFormatException {
        JFrame adicionarJogoFrame = new JFrame("Adicionar Jogo");
        adicionarJogoFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        adicionarJogoFrame.setBounds(100, 100, 400, 500);
        JPanel panel = new JPanel();
        panel.setLayout(null);
        adicionarJogoFrame.setContentPane(panel);

        JLabel labelNomeJogo = new JLabel("Nome do Jogo:");
        labelNomeJogo.setBounds(30, 30, 120, 20);
        panel.add(labelNomeJogo);

        fieldNomeJogo = new JTextField();
        fieldNomeJogo.setBounds(150, 30, 200, 20);
        panel.add(fieldNomeJogo);

        JLabel labelEmpresa = new JLabel("Empresa:");
        labelEmpresa.setBounds(30, 70, 120, 20);
        panel.add(labelEmpresa);

        fieldEmpresa = new JTextField();
        fieldEmpresa.setBounds(150, 70, 200, 20);
        panel.add(fieldEmpresa);

        JLabel labelAno = new JLabel("Ano de Lançamento:");
        labelAno.setBounds(30, 110, 150, 20);
        panel.add(labelAno);

        fieldAno = new JTextField();
        fieldAno.setBounds(150, 110, 200, 20);
        panel.add(fieldAno);

        JLabel labelNota = new JLabel("Sua Nota:");
        labelNota.setBounds(30, 150, 120, 20);
        panel.add(labelNota);

        fieldNota = new JTextField();
        fieldNota.setBounds(150, 150, 200, 20);
        panel.add(fieldNota);

        JLabel labelGenero = new JLabel("Gênero:");
        labelGenero.setBounds(30, 190, 120, 20);
        panel.add(labelGenero);

        fieldGenero = new JTextField();
        fieldGenero.setBounds(150, 190, 200, 20);
        panel.add(fieldGenero);
        
        
        JLabel labelPosse = new JLabel("Possui:");
        labelPosse.setBounds(30, 220, 120, 20);
        panel.add(labelPosse);
        
        JRadioButton posseSim = new JRadioButton("Sim");
        posseSim.setBounds(150, 220, 50, 20);
        panel.add(posseSim);
        
        JRadioButton posseNao = new JRadioButton("Não");
        posseNao.setBounds(210, 220, 50, 20);
        panel.add(posseNao);
        
        
        ButtonGroup grupoPosse = new ButtonGroup();
        grupoPosse.add(posseSim);
        grupoPosse.add(posseNao);

        JButton botaoSalvar = new JButton("Salvar");
        botaoSalvar.setBounds(150, 260, 100, 30);
        botaoSalvar.addActionListener(e -> {
            try {
                // Verificar se todos os campos estão preenchidos
                if (fieldNomeJogo.getText().trim().isEmpty() || fieldEmpresa.getText().trim().isEmpty() || 
                    fieldAno.getText().trim().isEmpty() || fieldNota.getText().trim().isEmpty() || 
                    fieldGenero.getText().trim().isEmpty()) {
                    throw new IllegalArgumentException("Por favor, preencha todos os campos!");
                }

                // Verificar se pelo menos um RadioButton está selecionado
                if (!posseSim.isSelected() && !posseNao.isSelected()) {
                    throw new IllegalArgumentException("Por favor, selecione se você possui o jogo.");
                }

                String nomeJogo = fieldNomeJogo.getText();
                String empresa = fieldEmpresa.getText();
                int ano = Integer.parseInt(fieldAno.getText());  // Pode gerar NumberFormatException
                int nota;
                
                try {
                    nota = Integer.parseInt(fieldNota.getText());  // Pode gerar NumberFormatException
                    // Verifica se a nota está dentro do intervalo esperado
                    if (nota < 1 || nota > 5) {
                        throw new IllegalArgumentException("Nota deve ser entre 1 e 5.");
                    }
                } catch (NumberFormatException ex) {
                    throw new IllegalArgumentException("Por favor, insira uma nota válida (número entre 1 e 5).");
                }
                
                String genero = fieldGenero.getText().trim();  // Elimina espaços extras

                // Verificar se o gênero é válido
                if (!genero.equalsIgnoreCase("rpg") && !genero.equalsIgnoreCase("aventura") && 
                    !genero.equalsIgnoreCase("luta") && !genero.equalsIgnoreCase("simulação") && 
                    !genero.equalsIgnoreCase("corrida") && !genero.equalsIgnoreCase("carta")) {
                    throw new IllegalArgumentException("Gênero inválido! Use um gênero válido.");
                }

                // Verificando a seleção de posse
                boolean possui = posseSim.isSelected();

                // Se os campos estiverem corretos, cria o jogo
                Game jogo = new Game(nomeJogo, genero, ano, empresa, matrizJogos, busca, player); // Passa o objeto busca
                if (possui) {
                    jogo.ter();
                } else {
                    jogo.naoPossui();
                }
                jogo.avaliar(nota);

                // Adiciona o jogo à matriz
                //matrizJogos.adicionarJogo(jogo);

                JOptionPane.showMessageDialog(adicionarJogoFrame, "Jogo adicionado com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);

            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(adicionarJogoFrame, ex.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        panel.add(botaoSalvar);

        JButton botaoVoltar = new JButton("Voltar");
        botaoVoltar.setBounds(260, 260, 100, 30);
        botaoVoltar.addActionListener(e -> adicionarJogoFrame.dispose());
        panel.add(botaoVoltar);

        adicionarJogoFrame.setVisible(true);
        
        
    }
}