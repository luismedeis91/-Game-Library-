package bibliotecaJogos;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.stream.Collectors;

public class CatalogoCSV {

    // salvar catálogo geral ou por gênero
    public static void salvarCatalogo(String caminhoArquivo, Collection<Game> jogos, String generoFiltro, MatrizJogos matrizJogos) {
        try {
            // Valida o filtro de gênero (caso tenha sido especificado)
            if (generoFiltro != null && !generoFiltro.isEmpty()) {
                if (!MatrizJogos.GENEROS_VALIDOS.contains(generoFiltro.toLowerCase())) {
                    throw new IllegalArgumentException("Gênero inválido para filtro: " + generoFiltro);
                }
            }

            // Verifica se há jogos para salvar
            if (jogos == null || jogos.isEmpty()) {
                throw new IllegalStateException("Nenhum jogo disponível para salvar no arquivo.");
            }

            // Filtra os jogos caso um gênero tenha sido especificado
            Collection<Game> jogosFiltrados = (generoFiltro != null && !generoFiltro.isEmpty())
                    ? jogos.stream().filter(jogo -> jogo.getGenero().equalsIgnoreCase(generoFiltro)).collect(Collectors.toList())
                    : jogos;

            // Verifica se a lista filtrada está vazia
            if (jogosFiltrados.isEmpty()) {
                throw new IllegalStateException("Nenhum jogo encontrado com o gênero especificado: " + generoFiltro);
            }

            // Apenas agora abre o FileWriter para salvar o arquivo
            try (FileWriter escritor = new FileWriter(caminhoArquivo)) {
                escritor.append("Índice Geral,Nome,Empresa,Ano,Gênero,Nota,Possui\n"); // Cabeçalho

                for (Game jogo : jogosFiltrados) {
                    int indiceGeral = matrizJogos.getIndiceGeral(jogo) + 1; // +1 para formato humano

                    escritor.append(String.valueOf(indiceGeral)).append(",")
                            .append(jogo.getNome()).append(",")
                            .append(jogo.getEmpresa()).append(",")
                            .append(String.valueOf(jogo.getAnoLancamento())).append(",")
                            .append(jogo.getGenero()).append(",")
                            .append(String.valueOf(jogo.getNota())).append(",")
                            .append(jogo.Possui() ? "Sim" : "Não").append("\n");
                }

                System.out.println("Catálogo salvo com sucesso no arquivo: " + caminhoArquivo);
            }
        } catch (IOException e) {
            System.err.println("Erro ao salvar o catálogo no arquivo CSV.");
        }
    }
}
