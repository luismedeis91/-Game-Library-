package bibliotecaJogos;

import java.util.HashMap;

public class buscaJogos {

    private HashMap<String, Game> catalogo;
    private MatrizJogos matrizJogos;

    
    public buscaJogos(MatrizJogos matrizJogos) {
        this.catalogo = new HashMap<>();
        this.matrizJogos = matrizJogos;
    }
    

    public void adicionarGame(Game jogo) {
        if (!catalogo.containsKey(jogo.getNome())) {
            catalogo.put(jogo.getNome(), jogo);
            //matrizJogos.adicionarJogo(jogo);		Deixei em comentário apenas essa parte que ele adiciona a Matriz, para não duplicar
            System.out.println("O jogo " + jogo.getNome() + " foi adicionado ao catalogo");
        } else {
            System.out.println(jogo.getNome() + " já foi adicionado ao catálogo");
        }
    }

    public void removerGame(String nome) {
        if (catalogo.containsKey(nome)) {
            Game jogoRemovido = catalogo.remove(nome);
            matrizJogos.removerJogo(jogoRemovido);
            System.out.println(nome + " foi removido do catalogo");
        } else {
            System.out.println(nome + " não está no catálogo");
        }
    }

    public Game buscaGame(String nome) {
        if (catalogo.containsKey(nome)) {
            return catalogo.get(nome);
        } else {
            System.out.println(nome + " Não foi encontrado");
            return null;
        }
    }

    public void salvarCatalogo(String caminhoArquivo, String generoFiltro) {
        CatalogoCSV.salvarCatalogo(caminhoArquivo, catalogo.values(), generoFiltro, matrizJogos);
    }
}
