package bibliotecaJogos;

public interface Avaliar {

	void avaliar(int nota);
	int getNota();

}
