package bibliotecaJogos;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Grafico {

    public static void main(String[] args) {

        JFrame janela = new JFrame();
        JLabel labelUser = new JLabel("Usuário:");
        JTextField userCamp = new JTextField();
        JPasswordField userPassword = new JPasswordField();
        JLabel passwordLabel = new JLabel("Senha:");

        passwordLabel.setBounds(50, 150, 100, 30);
        userPassword.setBounds(50, 180, 150, 30);

        userCamp.setBounds(50, 80, 150, 30);
        labelUser.setBounds(50, 50, 100, 30);

        JButton botao = new JButton("Login");
        botao.setBounds(50, 230, 200, 30);
        botao.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String user = userCamp.getText();
                System.out.println("Seja muito bem-vindo, " +
                        user.substring(0, 1).toUpperCase() + user.substring(1).toLowerCase());

                // Chama a nova janela
                abrirQuiz(user);
            }
        });

        janela.add(botao);
        janela.add(labelUser);
        janela.add(userCamp);
        janela.add(userPassword);
        janela.add(passwordLabel);

        janela.setLayout(null);
        janela.setBounds(400, 600, 400, 600);
        janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        janela.setVisible(true);
    }


    public static void abrirQuiz(String user) {
        JFrame quiz = new JFrame("Quiz");
        JLabel mensagem = new JLabel("Olá, " + user + ", responda as perguntas a seguir:");
        mensagem.setBounds(20, 10, 360, 30);
        
        quiz.add(mensagem);
      

        // Pergunta 1
        JLabel pergunta0 = new JLabel("1. Naruto Hokage VS Goku SSJ 4");
        pergunta0.setBounds(20, 50, 350, 20);
        JRadioButton opcao0 = new JRadioButton("Naruto");
        JRadioButton opcao1 = new JRadioButton("Goku");
        ButtonGroup g1 = new ButtonGroup();
        g1.add(opcao0);
        g1.add(opcao1);
        opcao0.setBounds(20, 70, 150, 20);
        opcao1.setBounds(20, 90, 150, 20);
        
        quiz.add(pergunta0);
        quiz.add(opcao0);
        quiz.add(opcao1);

        // Pergunta 2
        JLabel pergunta1 = new JLabel("2. Batman VS Naruto em formas básicas");
        pergunta1.setBounds(20, 140, 350, 20);
        JRadioButton opcao2 = new JRadioButton("Naruto");
        JRadioButton opcao3 = new JRadioButton("Batman");
        ButtonGroup g2 = new ButtonGroup();
        g2.add(opcao2);
        g2.add(opcao3);
        opcao2.setBounds(20, 160, 150, 20);
        opcao3.setBounds(20, 180, 150, 20);
        
        
        quiz.add(pergunta1);
        quiz.add(opcao2);
        quiz.add(opcao3);
        
        

        // Pergunta 3
        JLabel pergunta2 = new JLabel("3. Jiren vs Kid Flash");
        pergunta2.setBounds(20, 230, 350, 20);
        JRadioButton opcao4 = new JRadioButton("Kid Flash");
        JRadioButton opcao5 = new JRadioButton("Jiren");
        ButtonGroup g3 = new ButtonGroup();
        g3.add(opcao4);
        g3.add(opcao5);
        opcao4.setBounds(20, 250, 150, 20);
        opcao5.setBounds(20, 270, 150, 20);
        
        
        quiz.add(pergunta2);
        quiz.add(opcao4);
        quiz.add(opcao5);

        
        JButton enviar  = new JButton("Enviar");
        enviar.setBounds(20, 330, 150, 30);
        quiz.add(enviar);
        enviar.addActionListener(new ActionListener() {
        
            @Override
            public void actionPerformed(ActionEvent e) {
               int acertos = 0;
               if(opcao0.isSelected()) {
            	   acertos++;
               }
               
               if(opcao2.isSelected()) {
            	   acertos++;
               }
               
               if(opcao4.isSelected()) {
            	   acertos++;
               }
               
               if(acertos==3) {
            	   JOptionPane.showMessageDialog(quiz, "Parabéns você passou no teste");
               }else {
            	   JOptionPane.showMessageDialog(quiz, "Você é um pouco deselegante no tocante a conhecimento gerais");
               }
            }
            
           
        });
      
       
        quiz.setLayout(null);
        quiz.setBounds(400, 600, 400, 400);
        quiz.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        quiz.setVisible(true);
    }
}
