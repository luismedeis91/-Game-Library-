package bibliotecaJogos;

public class Game implements Avaliar, gerenciarPosse {

    private String nome;
    private String genero;
    private int anoLancamento;
    private String empresa;
    private int nota; // Apenas uma nota
    private boolean emPosse;

    // Getters e Setters com validações
    public String getNome() {
        return nome;
    }

    public void setNome(String nome, buscaJogos busca) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("O nome do jogo não pode estar vazio.");
        }
        
        // Verificar se o nome já existe em outro jogo
        if (busca.buscaGame(nome) != null) {
            throw new IllegalArgumentException("Já existe um jogo com o nome '" + nome + ".");
        }
        
        this.nome = nome;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        if (!MatrizJogos.GENEROS_VALIDOS.contains(genero.toLowerCase())) {
            throw new IllegalArgumentException("Gênero inválido: " + genero);
        }
        this.genero = genero;
    }

    public int getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(int anoLancamento) {
        if (anoLancamento < 0) {
            throw new IllegalArgumentException("Você realmente colocou um ano negativo?");
        }
        this.anoLancamento = anoLancamento;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        if (empresa == null || empresa.trim().isEmpty()) {
            throw new IllegalArgumentException("A empresa não pode estar vazia.");
        }
        this.empresa = empresa;
    }

    // Construtor atualizado
    public Game(String nome, String genero, int anoLancamento, String empresa, MatrizJogos matriz, buscaJogos busca, Player player) {
        try {
            setNome(nome, busca); // Valida o nome com o catálogo
            setGenero(genero); // Valida o gênero
            setAnoLancamento(anoLancamento); // Valida o ano de lançamento
            setEmpresa(empresa); // Valida a empresa

            this.emPosse = false; // Inicialmente, o jogo não está em posse
            this.nota = 0;

            // Adiciona o jogo à matriz e busca, caso válido
            matriz.adicionarJogo(this);
            player.adicionarJogo(this);
            busca.adicionarGame(this);

        } catch (IllegalArgumentException e) {
            // Exibe mensagem de erro e impede a criação do jogo
            System.err.println("Erro ao criar jogo: " + e.getMessage());
            this.nome = null;
        }
    }

    // Métodos adicionais
    public void exibirDetalhes() {
        System.out.println("Título: " + this.nome);
        System.out.println("Gênero: " + this.genero);
        System.out.println("Lançamento: " + this.anoLancamento);
        System.out.println("Empresa: " + this.empresa);
    }

    @Override
    public void avaliar(int nota) {
        if (nota < 1 || nota > 5) {
            throw new IllegalArgumentException("Nota inválida. Deve estar entre 1 e 5.");
        }
        this.nota = nota;
        System.out.println("Jogo '" + nome + "' avaliado com nota: " + nota);
    }

    @Override
    public int getNota() {
        return nota;
    }

    @Override
    public boolean Possui() {
        return emPosse;
    }

    @Override
    public void naoPossui() {
        emPosse = false; // Define como "não em posse"
        System.out.println("O jogo '" + nome + "' não está em posse.");
    }

    public void ter() {
        emPosse = true; // Define como "em posse"
        System.out.println("O jogo '" + nome + "' está em posse.");
    }
}

