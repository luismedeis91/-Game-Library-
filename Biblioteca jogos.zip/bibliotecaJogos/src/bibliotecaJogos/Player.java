package bibliotecaJogos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Player extends MatrizJogos {

    public void dados() {
        Map<String, Integer> contadorGeneros = new HashMap<>();
        for (int linha : indicesPorGenero.keySet()) {
            List<Game> jogosDoGenero = indicesPorGenero.get(linha);
            String genero = getNomeGenero(linha);
            contadorGeneros.put(genero, jogosDoGenero.size());
        }

        System.out.println("Estatística de jogos já adicionados:");
        contadorGeneros.forEach((genero, quantidade) -> {
            System.out.println("Gênero: " + genero + " - Jogos: " + quantidade);
        });

        String generoMaisJogos = contadorGeneros.entrySet().stream()
        		.max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse("Nenhum gênero");

        int quantidadeMaisJogos = contadorGeneros.getOrDefault(generoMaisJogos, 0);
        System.out.println("\nGênero mais comum: " + generoMaisJogos + " (" + quantidadeMaisJogos + " jogos)");
    }
}
